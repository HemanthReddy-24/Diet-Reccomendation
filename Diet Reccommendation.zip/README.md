This Diet Recommendation system will provide your diet for three different timings that are Breakfast, Lunch and Dinner.

Iam going to use HTML,CSS and Java Script for making website and python for including machine learning model.

This project is incomplete and in process.
